import entidades.*;
import repositorios.InMemoryRepository;

import java.time.LocalTime;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Repositorios
        InMemoryRepository<Empresa> empresaRepo = new InMemoryRepository<>();
        InMemoryRepository<Sucursal> sucursalRepo = new InMemoryRepository<>();
        InMemoryRepository<SucursalArticulo> sucursalArticuloRepo = new InMemoryRepository<>();
        InMemoryRepository<Categoria> categoriaRepo = new InMemoryRepository<>();
        InMemoryRepository<ArticuloInsumo> insumoRepo = new InMemoryRepository<>();
        InMemoryRepository<ArticuloManufacturado> manufacturadoRepo = new InMemoryRepository<>();
        InMemoryRepository<UnidadMedida> unidadRepo = new InMemoryRepository<>();

        // Geografía
        Pais argentina = Pais.builder().id(1L).nombre("Argentina").build();
        Provincia buenosAires = Provincia.builder().id(2L).nombre("Buenos Aires").pais(argentina).build();
        Localidad caba = Localidad.builder().id(4L).nombre("CABA").provincia(buenosAires).build();
        Domicilio domicilioCaba = new Domicilio(1L, "Av. Corrientes", 1234, 1000, caba, 5, 2);

        // Sucursal
        Sucursal sucursal1 = Sucursal.builder()
                .nombre("Sucursal CABA")
                .domicilio(domicilioCaba)
                .horarioApertura(LocalTime.of(9, 0))
                .horarioCierre(LocalTime.of(18, 0))
                .esCasaMatriz(true)
                .build();
        sucursalRepo.save(sucursal1);

        // Empresa
        Empresa empresa1 = Empresa.builder()
                .nombre("Empresa Uno")
                .razonSocial("Empresa Uno S.A.")
                .cuit(30500123)
                .cuil(20305001234L)
                .logo("logo1.png")
                .build();
        empresa1.agregarSucursal(sucursal1);
        empresaRepo.save(empresa1);

        // Categorías y unidades
        Categoria pizzas = Categoria.builder().denominacion("Pizzas").esInsumo(false).build();
        Categoria sandwiches = Categoria.builder().denominacion("Sandwiches").esInsumo(false).build();
        Categoria insumos = Categoria.builder().denominacion("Insumos").esInsumo(true).build();
        categoriaRepo.save(pizzas);
        categoriaRepo.save(sandwiches);
        categoriaRepo.save(insumos);

        UnidadMedida kg = UnidadMedida.builder().denominacion("Kg").build();
        UnidadMedida litro = UnidadMedida.builder().denominacion("Litro").build();
        UnidadMedida gramos = UnidadMedida.builder().denominacion("Gramos").build();
        unidadRepo.save(kg);
        unidadRepo.save(litro);
        unidadRepo.save(gramos);

        // Insumos
        ArticuloInsumo sal = ArticuloInsumo.builder().denominacion("Sal").precioCompra(1.0).stockActual(100).stockMinimo(10).stockMaximo(200).esParaElaborar(true).unidadMedida(gramos).categoria(insumos).build();
        ArticuloInsumo harina = ArticuloInsumo.builder().denominacion("Harina").precioCompra(0.5).stockActual(50).stockMinimo(5).stockMaximo(100).esParaElaborar(true).unidadMedida(kg).categoria(insumos).build();
        ArticuloInsumo aceite = ArticuloInsumo.builder().denominacion("Aceite").precioCompra(3.0).stockActual(30).stockMinimo(3).stockMaximo(60).esParaElaborar(true).unidadMedida(litro).categoria(insumos).build();
        ArticuloInsumo carne = ArticuloInsumo.builder().denominacion("Carne").precioCompra(5.0).stockActual(20).stockMinimo(2).stockMaximo(40).esParaElaborar(true).unidadMedida(kg).categoria(insumos).build();
        insumoRepo.save(sal);
        insumoRepo.save(harina);
        insumoRepo.save(aceite);
        insumoRepo.save(carne);

        // Manufacturados
        ArticuloManufacturado pizza = ArticuloManufacturado.builder()
                .denominacion("Pizza Hawaina")
                .precioVenta(12.0)
                .descripcion("Pizza con piña y jamón")
                .tiempoEstimadoMinutos(20)
                .preparacion("Hornear por 20 minutos")
                .categoria(pizzas)
                .unidadMedida(kg)
                .articuloManufacturadoDetalles(Set.of(
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(sal).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(2).articuloInsumo(harina).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(aceite).build()
                ))
                .build();

        ArticuloManufacturado lomo = ArticuloManufacturado.builder()
                .denominacion("Lomo Completo")
                .precioVenta(15.0)
                .descripcion("Lomo completo con todos los ingredientes")
                .tiempoEstimadoMinutos(25)
                .preparacion("Cocinar a la parrilla por 25 minutos")
                .categoria(sandwiches)
                .unidadMedida(kg)
                .articuloManufacturadoDetalles(Set.of(
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(sal).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(aceite).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(2).articuloInsumo(carne).build()
                ))
                .build();

        manufacturadoRepo.save(pizza);
        manufacturadoRepo.save(lomo);

        // Asociar artículos a sucursal
        SucursalArticulo sa1 = SucursalArticulo.builder()
                .sucursal(sucursal1)
                .articulo(pizza)
                .stock(10)
                .precioLocal(13.0)
                .activo(false)
                .observaciones("Pendiente de aprobación")
                .build();

        SucursalArticulo sa2 = SucursalArticulo.builder()
                .sucursal(sucursal1)
                .articulo(lomo)
                .stock(5)
                .precioLocal(16.0)
                .activo(false)
                .observaciones("Pendiente de aprobación")
                .build();

        sucursalArticuloRepo.save(sa1);
        sucursalArticuloRepo.save(sa2);

        // Hardcodear productos aprobados para sucursal1
        Set<String> productosAprobados = Set.of("Pizza Hawaina", "Lomo Completo");
        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("\nAprobando productos para " + sucursal1.getNombre());
        sucursalArticuloRepo.findAll().stream()
                .filter(sa -> sa.getSucursal().equals(sucursal1))
                .forEach(sa -> {
                    if (productosAprobados.contains(sa.getArticulo().getDenominacion())) {
                        sa.setActivo(true);
                        sa.setObservaciones("Producto aprobado para la venta");
                        System.out.println("✔ Aprobado: " + sa.getArticulo().getDenominacion());
                    } else {
                        System.out.println("✖ No aprobado: " + sa.getArticulo().getDenominacion());
                    }
                });

        // Mostrar artículos por sucursal
        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("\nArtículos disponibles por sucursal:");

        for (Sucursal sucursal : sucursalRepo.findAll()) {
            System.out.println("Sucursal: " + sucursal.getNombre());
            sucursalArticuloRepo.findAll().stream()
                    .filter(sa -> sa.getSucursal().equals(sucursal))
                    .forEach(sa -> System.out.println("  - " + sa.getArticulo().getDenominacion() + " | Stock: " + sa.getStock() + " | Precio: $" + sa.getPrecioLocal() + " | Aprobado: " + sa.getActivo()));
        }
        System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
}