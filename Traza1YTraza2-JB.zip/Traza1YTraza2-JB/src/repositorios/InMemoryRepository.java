package repositorios;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Repositorio genérico que simula persistencia en memoria.
 * Funciona con cualquier entidad que tenga un método público setId(Long).
 */
public class InMemoryRepository<T> {
    protected Map<Long, T> data = new HashMap<>();
    protected AtomicLong idGenerator = new AtomicLong();

    /**
     * Guarda una entidad y le asigna un ID único.
     */
    public T save(T entity) {
        long id = idGenerator.incrementAndGet();
        try {
            entity.getClass().getMethod("setId", Long.class).invoke(entity, id);
            System.out.println(entity.getClass().getSimpleName() + " guardado con ID: " + id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        data.put(id, entity);
        return entity;
    }

    /**
     * Busca una entidad por su ID.
     */
    public Optional<T> findById(Long id) {
        return Optional.ofNullable(data.get(id));
    }

    /**
     * Devuelve todas las entidades guardadas.
     */
    public List<T> findAll() {
        return new ArrayList<>(data.values());
    }

    /**
     * Actualiza una entidad existente manteniendo su ID.
     */
    public Optional<T> genericUpdate(Long id, T updatedEntity) {
        if (!data.containsKey(id)) return Optional.empty();
        try {
            updatedEntity.getClass().getMethod("setId", Long.class).invoke(updatedEntity, id);
            data.put(id, updatedEntity);
            return Optional.of(updatedEntity);
        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    /**
     * Elimina una entidad por su ID.
     */
    public Optional<T> genericDelete(Long id) {
        return Optional.ofNullable(data.remove(id));
    }

    /**
     * Busca entidades por el valor de un campo usando reflexión.
     */
    public List<T> genericFindByField(String fieldName, Object value) {
        List<T> results = new ArrayList<>();
        try {
            for (T entity : data.values()) {
                Method getter = entity.getClass().getMethod("get" + capitalize(fieldName));
                Object fieldValue = getter.invoke(entity);
                if (fieldValue != null && fieldValue.equals(value)) {
                    results.add(entity);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    /**
     * Capitaliza el nombre del campo para construir el getter.
     */
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
