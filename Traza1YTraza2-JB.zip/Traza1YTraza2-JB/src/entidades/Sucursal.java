package entidades;


import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalTime;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@SuperBuilder
public class Sucursal {
    @EqualsAndHashCode.Include
    private Long id;
    @EqualsAndHashCode.Include
    private String nombre;

    private Domicilio domicilio;
    private LocalTime horarioApertura;
    private LocalTime horarioCierre;
    private Boolean esCasaMatriz;

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Sucursal{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", horarioApertura=" + horarioApertura +
                ", horarioCierre=" + horarioCierre +
                ", esCasaMatriz=" + esCasaMatriz +
                ", domicilio=" + domicilio +
                '}';
    }
}